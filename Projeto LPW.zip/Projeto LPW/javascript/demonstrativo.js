alert("Bora mermão acorde pra aula!!!")
document.write("Última modificação feita em: " + document.lastModified)